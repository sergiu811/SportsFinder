--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "sportFinder";
--
-- Name: sportFinder; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "sportFinder" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "sportFinder" OWNER TO postgres;

\connect "sportFinder"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: court; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.court (
    court_id integer NOT NULL,
    court_name character varying(100) NOT NULL,
    court_longitude numeric NOT NULL,
    court_latitude numeric NOT NULL,
    image character varying(255)
);


ALTER TABLE public.court OWNER TO postgres;

--
-- Name: basketball_courts_court_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.basketball_courts_court_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.basketball_courts_court_id_seq OWNER TO postgres;

--
-- Name: basketball_courts_court_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.basketball_courts_court_id_seq OWNED BY public.court.court_id;


--
-- Name: lobby; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lobby (
    lobby_id integer NOT NULL,
    court_id integer NOT NULL,
    time_id integer NOT NULL,
    player_id integer NOT NULL,
    date character varying(255) NOT NULL
);


ALTER TABLE public.lobby OWNER TO postgres;

--
-- Name: lobby_lobby_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.lobby ALTER COLUMN lobby_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lobby_lobby_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player (
    playerid integer NOT NULL,
    username character varying(255) NOT NULL,
    passwordhash character varying(255) NOT NULL,
    rating double precision,
    userid character varying(255) NOT NULL,
    height integer,
    age integer
);


ALTER TABLE public.player OWNER TO postgres;

--
-- Name: player_playerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.player ALTER COLUMN playerid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.player_playerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: time_interval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_interval (
    time_id integer NOT NULL,
    time_interval character varying(255)
);


ALTER TABLE public.time_interval OWNER TO postgres;

--
-- Name: time_interval_time_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.time_interval ALTER COLUMN time_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.time_interval_time_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: court court_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.court ALTER COLUMN court_id SET DEFAULT nextval('public.basketball_courts_court_id_seq'::regclass);


--
-- Data for Name: court; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.court (court_id, court_name, court_longitude, court_latitude, image) FROM stdin;
\.
COPY public.court (court_id, court_name, court_longitude, court_latitude, image) FROM '$$PATH$$/3611.dat';

--
-- Data for Name: lobby; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lobby (lobby_id, court_id, time_id, player_id, date) FROM stdin;
\.
COPY public.lobby (lobby_id, court_id, time_id, player_id, date) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player (playerid, username, passwordhash, rating, userid, height, age) FROM stdin;
\.
COPY public.player (playerid, username, passwordhash, rating, userid, height, age) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: time_interval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_interval (time_id, time_interval) FROM stdin;
\.
COPY public.time_interval (time_id, time_interval) FROM '$$PATH$$/3615.dat';

--
-- Name: basketball_courts_court_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.basketball_courts_court_id_seq', 11, true);


--
-- Name: lobby_lobby_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lobby_lobby_id_seq', 499, true);


--
-- Name: player_playerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.player_playerid_seq', 11, true);


--
-- Name: time_interval_time_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_interval_time_id_seq', 7, true);


--
-- Name: court basketball_courts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.court
    ADD CONSTRAINT basketball_courts_pkey PRIMARY KEY (court_id);


--
-- Name: lobby lobby_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lobby
    ADD CONSTRAINT lobby_pkey PRIMARY KEY (lobby_id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (playerid);


--
-- Name: time_interval time_interval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_interval
    ADD CONSTRAINT time_interval_pkey PRIMARY KEY (time_id);


--
-- Name: lobby lobby_court; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lobby
    ADD CONSTRAINT lobby_court FOREIGN KEY (court_id) REFERENCES public.court(court_id);


--
-- Name: lobby lobby_player; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lobby
    ADD CONSTRAINT lobby_player FOREIGN KEY (player_id) REFERENCES public.player(playerid) NOT VALID;


--
-- Name: lobby lobby_time; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lobby
    ADD CONSTRAINT lobby_time FOREIGN KEY (time_id) REFERENCES public.time_interval(time_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

